// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  AUTH_API_URL: 'http://34.245.20.237/api',
  API_BASE_URL: '',
  API_CLIENT_ID: '27ea860e-ddc3-11e8-9f32-f2801f1b9fd1',
  API_CLIENT_SECRET: '4jLEBu3z2ycymHkcGsDaD9EJhkuMPqRlLwewZUDM',
  AUTH_API_CLIENT_ID: 3,
  AUTH_API_CLIENT_SECRET: '3vTixUlzM18XlN1owGm7BUWSm8o7Dg8eyBR6VOR2',
};

/*
 * In development mode, to ignore zone related error stack frames such as
 * `zone.run`, `zoneDelegate.invokeTask` for easier debugging, you can
 * import the following file, but please comment it out in production mode
 * because it will have performance impact when throw error
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
