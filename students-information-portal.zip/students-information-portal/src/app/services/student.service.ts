import { Injectable, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { APIService } from './api.service';
import { StudentInterface } from '../models/student-interface';
import { Student } from '../models/student';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { ResponseInterface } from '../models/response-Interface';
import { ResponseDataInterface } from '../models/response-data-interface';

@Injectable({
  providedIn: 'root'
})
export class StudentService extends APIService {

  constructor(public http: HttpClient) {
    super(http);

  }
  // http://156.0.234.100/sip/public/api/v1/users/profile/31931421-d90c-4234-823c-c18ea0d0f112

  public getCredential(studentId: string = '31931421-d90c-4234-823c-c18ea0d0f112'): Observable<any> {
    return this.get(`http://156.0.234.100/sip/public/api/v1/users/profile/${studentId}`, {}).pipe( map( (response) => {
      return response;
    } ));
  }

}
