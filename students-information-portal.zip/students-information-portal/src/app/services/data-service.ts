import { Injectable } from '@angular/core';
import { finalize } from 'rxjs/operators';
import { Student } from '../models/student';
import { StudentInterface } from '../models/student-interface';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  institution = 'default';

  constructor() { }

  public setStudentInfo(student: Student) {
    sessionStorage.setItem('student', JSON.stringify(student));
  }

  public addDataToSession(key, value) {
    sessionStorage.setItem(key, JSON.stringify(value));
  }

  public getStoredSession(key: string) {
    return JSON.parse(sessionStorage.getItem(key));
  }

  public getStudentInfo(): Student {
    return JSON.parse(sessionStorage.getItem('student'));
  }

}
