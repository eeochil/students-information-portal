import { Injectable } from '@angular/core';
import { APIService } from './api.service';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';
import { ToastrService } from 'ngx-toastr';
import { CourseInterface } from '../models/course-interface';
import { ResponseInterface } from '../models/response-Interface';
import { StudentService } from './student.service';

@Injectable({
  providedIn: 'root'
})
export class CourseRegistrationService extends APIService {

  constructor(public http: HttpClient, private toastr: ToastrService, private studentService: StudentService) {
    super(http);

  }
  // Know if registration is opened.
  // ===============================
  isActiveRegistrationSchedule(student_id: string = '31931421-d90c-4234-823c-c18ea0d0f112'): Observable<ResponseInterface> {
    // tslint:disable-next-line:max-line-length
    return this.get(`http://156.0.234.100/sip/public/api/v1/users/schedule/${student_id}`).pipe(map(response => response));
  }


  getRegistrationCourse(student_id: string): Observable<ResponseInterface> {
    return this.get(`http://156.0.234.100/sip/public/api/v1/users/courseRegistration/getCourses/${student_id}`, {}).pipe(map((response) => {
      response.data.course = <CourseInterface>response.data.course;
      return response;
    }));
  }

  addCourse(course_id: number): Observable<any> {
    // this.studentService.
    return this.post('', {'course_id': course_id}).pipe(map(response => response));
  }

  dropCourse(course_id: number): Observable<any> {
    return this.post('', {'course_id': course_id}).pipe(map(response => response));
  }

  registerCoursesAdded(coursesToRegister: object[], minCredit: number, maxCredit: number): Observable<any> {
    if (coursesToRegister.length > minCredit && coursesToRegister.length < maxCredit) {
      return this.post('', coursesToRegister).pipe(map(response => response));
    } else {
      if (coursesToRegister.length < minCredit) {
        this.toastr.info('Sorry, can\'t register since you\'ve less credit hours than authorized.');
      } else if (coursesToRegister.length > maxCredit) {
        this.toastr.info('Sorry, can\'t register since you\'ve more credit hours than authorized.');
      }
      return of({message: 'sorry'});
    }

  }
}
