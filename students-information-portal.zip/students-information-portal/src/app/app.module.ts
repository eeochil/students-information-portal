import * as $ from 'jquery';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {
  CommonModule
} from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { Routes, RouterModule } from '@angular/router';


import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AgmCoreModule } from '@agm/core';

import { FullComponent } from './views/layouts/full/full.component';
import { BlankComponent } from './views/layouts/blank/blank.component';

import { NavigationComponent } from './views/shared/header-navigation/navigation.component';
import { SidebarComponent } from './views/shared/sidebar/sidebar.component';
import { BreadcrumbComponent } from './views/shared/breadcrumb/breadcrumb.component';

import { Approutes } from './app-routing.module';
import { AppComponent } from './app.component';
import { SpinnerComponent } from './views/shared/spinner.component';

import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import { LoginComponent } from './views/login/login.component';
import { RulesAndRegulationsComponent } from './views/rules-and-regulations/rules-and-regulations.component';
import { PlanComponent } from './views/plan/plan.component';
import { ResultComponent } from './views/result/result.component';
import { TimetableComponent } from './views/timetable/timetable.component';
import { RegistrationComponent } from './views/registration/registration.component';
import { DocumentRequestsComponent } from './views/document-requests/document-requests.component';
import { AccountsComponent } from './views/accounts/accounts.component';
import { LecturerEvaluationComponent } from './views/lecturer-evaluation/lecturer-evaluation.component';
import { ProfileComponent } from './views/profile/profile.component';
import { AccountSettingsComponent } from './views/profile/account-settings/account-settings.component';
import { NotfoundComponent } from './views/404/not-found.component';
import { ResitRegistrationsComponent } from './views/registration/resit-registrations/resit-registrations.component';
import { CourseRegistrationsComponent } from './views/registration/course-registrations/course-registrations.component';
import { AngularMaterialUsageModule } from './views/angular-material-usage/angular-material-usage.module';
import { UserCredentialComponent } from './views/user-credential/user-credential.component';
import { ToastrService, ToastrModule } from 'ngx-toastr';

const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  suppressScrollX: true,
  wheelSpeed: 1,
  wheelPropagation: true,
  minScrollbarLength: 20
};

@NgModule({
  declarations: [
    NotfoundComponent,
    LoginComponent,
    AppComponent,
    SpinnerComponent,
    FullComponent,
    BlankComponent,
    NavigationComponent,
    BreadcrumbComponent,
    SidebarComponent,
    ResitRegistrationsComponent,
    CourseRegistrationsComponent,
    RegistrationComponent,
    RulesAndRegulationsComponent,
    PlanComponent,
    ResultComponent,
    TimetableComponent,
    DocumentRequestsComponent,
    AccountsComponent,
    LecturerEvaluationComponent,
    ProfileComponent,
    AccountSettingsComponent,
    UserCredentialComponent
  ],
  imports: [
    AngularMaterialUsageModule,
    BrowserAnimationsModule,
    CommonModule,
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
    NgbModule,
    RouterModule.forRoot(Approutes),
    ToastrModule.forRoot(),
    PerfectScrollbarModule,
    AgmCoreModule.forRoot({ apiKey: 'AIzaSyBUb3jDWJQ28vDJhuQZxkC0NXr_zycm8D0' })
  ],
  providers: [
    {
      provide: PERFECT_SCROLLBAR_CONFIG,
      useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
    }, ToastrService
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
