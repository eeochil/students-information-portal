export interface StudentGuardian {
     name: string;
     address: string;
     mobile: number;
     email: string;
     type: string;
}
