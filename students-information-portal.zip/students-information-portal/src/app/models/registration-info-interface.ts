export interface RegistrationInfoInterface {
  registrationSchedule: {
    schedule_id: number,
    start_date: string,
    end_date: string,
    resit: string,
    stream_id: number,
    semester_id: number,
    active: number
  };
  semester: {
      semester_id: number,
      semester: string
  };
}
