import { StudentGuardian } from './student-guardian';
import { StudentInterface } from './student-interface';

export interface ResponseDataInterface {
     personal_data: StudentInterface;
     guardian_data: Array<StudentGuardian>;
     meta_data: object;
}
