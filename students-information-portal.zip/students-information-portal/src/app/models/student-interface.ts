import { StudentGuardian } from './student-guardian';

export interface StudentInterface {

     // profilePic: string;
     othernames?: string;
     surname?: string;
     student_id?: string;
     sex?: string;
     dob?: string;
    // indexNumber: number;
     doa?: string;
     doc?: string;
    // department: string;
     program_id?: number;
     long_name?: string;
     // stream: string | 'morning';
     email?: string;
     // personalEmail ?: string | '';
     mobile ?: string | number | '';
     // resident ?: string | '';
     // guardian ?: StudentGuardian[] | [];


     // id: number;
     // userId: number;
     // title: string;
     // completed: boolean;

}
