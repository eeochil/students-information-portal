import { ResponseDataInterface } from './response-data-interface';

export interface ResponseInterface {
     data: any;
     responseMessage: string;
     responseCode: string;
}
