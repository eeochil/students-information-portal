import { StudentInterface } from './student-interface';
import { StudentGuardian } from './student-guardian';

export class Student implements StudentInterface {
     // interface variables
     othernames: string|'';
     surname: string|'';
     student_id: string|'';
     sex: string|'';
     dob: string| '';
     doa: string|'';
     doc: string|'';
     program_id: number;
     long_name: string|'';
     email: string|'';
     mobile: string | number | '';
     guardians: Array<StudentGuardian> = [];
     // this classes variables
     fullName: string;
     constructor(private student: StudentInterface) {
          // this.profilePic = student.profilePic;
          this.othernames = student.othernames;
          this.surname = student.surname;
          this.student_id = student.student_id;
          this.dob = student.dob;
          this.doa = student.doa;
          this.doc = student.doc;
          this.long_name = student.long_name;
          this.program_id = student.program_id;
          // this.stream = student.stream;
          this.email = student.email;
          // this.personalEmail = student.personalEmail;
          this.mobile = student.mobile;
          this.sex = student.sex;
          this.fullName  = `${this.othernames} ${this.surname}`;

     }


}
