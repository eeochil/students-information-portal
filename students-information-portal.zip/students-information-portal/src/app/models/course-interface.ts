export interface CourseInterface {
     id: number;
     code: string;
     title: string;
     credit: number;
     status: string;
}
