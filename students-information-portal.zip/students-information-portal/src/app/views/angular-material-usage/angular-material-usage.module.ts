import { NgModule } from '@angular/core';
import {MatExpansionModule, MatTabsModule} from '@angular/material';

// angular component import here, make sure it is exported.

@NgModule({
  imports: [
    MatExpansionModule,
    MatTabsModule
  ],
  exports: [
    MatExpansionModule,
    MatTabsModule
  ]
})
export class AngularMaterialUsageModule { }
