import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rules-and-regulations',
  templateUrl: './rules-and-regulations.component.html',
  styleUrls: ['./rules-and-regulations.component.css']
})
export class RulesAndRegulationsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
