import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-resit-registrations',
  templateUrl: './resit-registrations.component.html',
  styleUrls: ['./resit-registrations.component.css']
})
export class ResitRegistrationsComponent implements OnInit {

  constructor(private toastr: ToastrService) { }

  ngOnInit() {
  }

  registerCourses() {
    this.toastr.info('courses registered');
  }

  resetRegistration() {
    this.toastr.info('all added courses has been dropped.');
  }
}
