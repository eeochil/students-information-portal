import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ResitRegistrationsComponent } from './resit-registrations.component';

describe('ResitRegistrationsComponent', () => {
  let component: ResitRegistrationsComponent;
  let fixture: ComponentFixture<ResitRegistrationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ResitRegistrationsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ResitRegistrationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
