import { Routes } from '@angular/router';
import { CourseRegistrationsComponent } from './course-registrations/course-registrations.component';
import { ResitRegistrationsComponent } from './resit-registrations/resit-registrations.component';
import { RegistrationComponent } from './registration.component';

export const registrationRoutes: Routes = [
  {
    path: 'registrations',
    children: [
      {
    path: 'course-registration',
    component: CourseRegistrationsComponent,
    data: {
      title: 'Course Registration',
      urls: [
        {title: 'home', url: '/home'},
        {title: 'registrations', url: '/home/registration'},
        {title: 'course registration'}
      ]
    }
  },
  {
    path: 'resit-registration',
    component: ResitRegistrationsComponent,
    data: {
      title: 'Resit Registration',
      urls: [
        {title: 'home', url: '/home'},
        {title: 'registrations', url: '/home/registration'},
        {title: 'resit registrations'}
      ]
    }
  }
    ]
  }
];
