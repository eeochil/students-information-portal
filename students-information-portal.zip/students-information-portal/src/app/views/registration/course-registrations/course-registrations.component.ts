import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { CourseRegistrationService } from '../../../services/course-registration.service';
import { CourseInterface } from '../../../models/course-interface';
import { Student } from '../../../models/student';
import { DataService } from '../../../services/data-service';
import { StudentService } from '../../../services/student.service';
import { StudentInterface } from '../../../models/student-interface';
import { ResponseInterface } from '../../../models/response-Interface';

@Component({
  selector: 'app-course-registrations',
  templateUrl: './course-registrations.component.html',
  styleUrls: ['./course-registrations.component.css']
})
export class CourseRegistrationsComponent implements OnInit {

  coursesMounted: CourseInterface[];
  registrationInfo: object;
  student: Student;

  constructor(private registrationService: CourseRegistrationService,
    private studentService: StudentService,
    private dataService: DataService, private toastr: ToastrService) {
    this.setStudent();
  }

  ngOnInit() {
    if (this.student == null) {
      this.studentService.getCredential().subscribe(
        response => {
          this.setDataServiceStudent(response);
          this.setStudent();
          this.getCourses(this.student.student_id);
        },
        error => {console.log(error); }
      );
    } else {
      this.getCourses(this.student.student_id);
    }
  }


  private setStudent() {
    this.student = this.dataService.getStudentInfo();
  }

  private setDataServiceStudent(response: ResponseInterface) {
    const studentData: StudentInterface = response.data.personal_data;
    this.student = new Student(studentData);
    this.student.guardians = response.data.guardian_data;
    this.dataService.setStudentInfo(this.student);
  }

  private getCourses(student_id: string) {
    this.registrationService.getRegistrationCourse(student_id).subscribe(
      response => {
        this.coursesMounted = response.data.registrationData;
        this.registrationInfo = response.data.semesterCredits;
      },
      error => {
        console.log(error);
      }
    );
  }

  addCourse(course: CourseInterface) {
    this.registrationService.addCourse(course.id).subscribe(
      addCourseResp => {
        console.log(addCourseResp);
      },
      error => {}
    );
  }

  dropCourse(course: CourseInterface) {
    this.registrationService.dropCourse(course.id).subscribe(
      addCourseResp => {
        console.log(addCourseResp);
      },
      error => {}
    );
  }

  confirmRegistration() {
    this.registrationService.registerCoursesAdded([], 2, 3).subscribe(
      addCourseResp => {
        console.log(addCourseResp);
      },
      error => {}
    );
  }

  resetRegistration() {

  }
}
