import { Component, OnInit } from '@angular/core';
import { CourseRegistrationService } from '../../services/course-registration.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { DataService } from '../../services/data-service';
import { Student } from '../../models/student';
import { StudentService } from '../../services/student.service';
import { StudentInterface } from '../../models/student-interface';
import { ResponseInterface } from '../../models/response-Interface';
import { RegistrationInfoInterface } from '../../models/registration-info-interface';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  student: Student;
  registrationInfo: RegistrationInfoInterface;

  constructor(
    private dataService: DataService, private studentService: StudentService,
    private registrationService: CourseRegistrationService,
    private toastr: ToastrService, private router: Router
  ) {}

  ngOnInit() {
    this.setStudent();

    if (this.student == null) {
      this.studentService.getCredential().subscribe(
        response => {
          this.setDataServiceStudent(response);
          this.setStudent();
          this.isActiveRegistration();
        },
        error => {console.log(error); }
      );
    } else {
      this.isActiveRegistration();
    }

  }
  // assign current student credentials.
  // ==================================
  private setStudent() {
    this.student = this.dataService.getStudentInfo();
  }

  private setDataServiceStudent(response: ResponseInterface) {
    const studentData: StudentInterface = response.data.personal_data;
    this.student = new Student(studentData);
    this.student.guardians = response.data.guardian_data;
    this.dataService.setStudentInfo(this.student);
  }

  // check registration Active or not
  // ================================
  private isActiveRegistration() {
    this.registrationInfo = this.dataService.getStoredSession('registrationInfo');

    if (this.registrationInfo === null) {
      this.registrationService.isActiveRegistrationSchedule(this.student.student_id).subscribe(
        response => {
          if (response.responseCode.trim().endsWith('200')) {
            this.dataService.addDataToSession('registrationInfo', response.data);
            this.registrationInfo = response.data;

          }
        },
        error => {
          console.log(error);
        }
      );
    }

  }

  // public methods
  // ==============

  // know which one is active to enable route for that button.
  // =========================================================
  routeTo(to = '', source: string) {
      this.router.navigate([to]);
      return;
  }



}
