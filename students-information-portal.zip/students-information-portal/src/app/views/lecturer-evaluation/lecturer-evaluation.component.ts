import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lecturer-evaluation',
  templateUrl: './lecturer-evaluation.component.html',
  styleUrls: ['./lecturer-evaluation.component.css']
})
export class LecturerEvaluationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
