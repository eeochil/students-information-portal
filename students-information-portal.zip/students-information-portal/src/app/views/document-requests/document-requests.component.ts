import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-document-requests',
  templateUrl: './document-requests.component.html',
  styleUrls: ['./document-requests.component.css']
})
export class DocumentRequestsComponent implements OnInit {

  constructor(private toastr: ToastrService) { }

  ngOnInit() {
  }

  makeDocumentRequest() {
    this.toastr.info('Document Request made.');
  }

}
