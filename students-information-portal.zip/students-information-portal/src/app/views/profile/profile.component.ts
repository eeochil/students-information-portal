import { Component, OnInit } from '@angular/core';
import { Student } from '../../models/student';
import { StudentService } from '../../services/student.service';
import { StudentInterface } from '../../models/student-interface';
import { DataService } from '../../services/data-service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  studentCredential: StudentInterface;
  student: Student;

  constructor(private studentService: StudentService, private dataService: DataService) {

  }

  ngOnInit() {
    this.student = this.dataService.getStudentInfo();

    // this statement is to get the student credentials again incase the getCredential fails in sidebar component.
    if (this.student === null) {
      this.studentService.getCredential().subscribe(
        response => {
          if (response.responseCode.trim().endsWith('200')) {
            const studentData: StudentInterface = response.data.personal_data;
            this.student = new Student(studentData);
            this.student.guardians = response.data.guardian_data;
          }
        },
        error => {console.log(error); }
      );
    }
  }


}
