import { Component, AfterViewInit, OnInit } from '@angular/core';
import { ROUTES } from './menu-items';
import { RouteInfo } from './sidebar.metadata';
import { Router, ActivatedRoute } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { StudentService } from '../../../services/student.service';
import { Student } from '../../../models/student';
import { StudentInterface } from '../../../models/student-interface';
import { DataService } from '../../../services/data-service';
declare var $: any;

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html'
})
export class SidebarComponent implements OnInit {
  showMenu = '';
  showSubMenu = '';


  student: Student;


  public sidebarnavItems: any[];
  // this is for the open close
  addExpandClass(element: any) {
    if (element === this.showMenu) {
      this.showMenu = '0';
    } else {
      this.showMenu = element;
    }
  }
  addActiveClass(element: any) {
    if (element === this.showSubMenu) {
      this.showSubMenu = '0';
    } else {
      this.showSubMenu = element;
    }
  }

  constructor(
    private modalService: NgbModal,
    private router: Router,
    private route: ActivatedRoute,
    private studentService: StudentService,
    public dataService: DataService
  ) {}

  // End open close
  ngOnInit() {
    this.sidebarnavItems = ROUTES.filter(sidebarnavItem => sidebarnavItem);
    this.studentService.getCredential().subscribe(
      response => {

        if (response.responseCode.trim().endsWith('200')) {
          const studentData: StudentInterface = response.data.personal_data;
          this.student = new Student(studentData);
          this.student.guardians = response.data.guardian_data;
          this.dataService.setStudentInfo(this.student);
        }
      },
      error => {console.log(error); }
    );
    // console.log(this.student);

  }
}
