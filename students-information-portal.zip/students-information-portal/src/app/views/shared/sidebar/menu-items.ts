import { RouteInfo } from './sidebar.metadata';

export const ROUTES: RouteInfo[] = [
  {
    path: '/home/rules-and-regulations',
    title: 'Rules and Regulations',
    icon: 'fas fa-shield-alt',
    class: '',
    extralink: false,
    submenu: []
  },
  {
    path: '/home/registration',
    title: 'Registrations',
    icon: 'fas fa-laptop',
    class: '',
    extralink: false,
    submenu: []
  },
  {
    path: '',
    title: 'Academic Track',
    icon: 'fas fa-book',
    class: 'has-arrow',
    extralink: false,
    submenu: [
      {
        path: '/home/plan',
        title: 'Plan',
        icon: 'fas fa-map-signs',
        class: '',
        extralink: false,
        submenu: []
      },
      {
        path: '/home/result',
        title: 'Results',
        icon: 'fas fa-database',
        class: '',
        extralink: false,
        submenu: []
      },
      {
        path: '/home/timetable',
        title: 'Timetable',
        icon: 'fas fa-table',
        class: '',
        extralink: false,
        submenu: []
      },

    ]
  },
  {
    path: '/home/document-requests',
    title: 'Document Requests',
    icon: 'fas fa-folder-open',
    class: '',
    extralink: false,
    submenu: []
  },
  {
    path: '/home/accounts',
    title: 'Accounts',
    icon: 'fas fa-briefcase',
    class: '',
    extralink: false,
    submenu: []
  },
  {
    path: '/home/lecturer-evaluation',
    title: 'Lecturer Evaluation',
    icon: 'fas fa-edit',
    class: '',
    extralink: false,
    submenu: []
  },
];
