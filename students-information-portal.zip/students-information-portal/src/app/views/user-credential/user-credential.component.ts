import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-credential',
  templateUrl: './user-credential.component.html',
  styleUrls: ['./user-credential.component.css']
})
export class UserCredentialComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
