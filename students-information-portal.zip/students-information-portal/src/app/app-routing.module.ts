import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FullComponent } from './views/layouts/full/full.component';
import { BlankComponent } from './views/layouts/blank/blank.component';
import { RulesAndRegulationsComponent } from './views/rules-and-regulations/rules-and-regulations.component';
import { LoginComponent } from './views/login/login.component';
import { PlanComponent } from './views/plan/plan.component';
import { ResultComponent } from './views/result/result.component';
import { TimetableComponent } from './views/timetable/timetable.component';
import { RegistrationComponent } from './views/registration/registration.component';
import { AccountsComponent } from './views/accounts/accounts.component';
import { LecturerEvaluationComponent } from './views/lecturer-evaluation/lecturer-evaluation.component';
import { DocumentRequestsComponent } from './views/document-requests/document-requests.component';
import { ProfileComponent } from './views/profile/profile.component';
import { AccountSettingsComponent } from './views/profile/account-settings/account-settings.component';
import { NotfoundComponent } from './views/404/not-found.component';
import { registrationRoutes } from './views/registration/registration-routing.module';

export const Approutes: Routes = [
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'home',
    component: FullComponent,
    children: [
      { path: '', redirectTo: 'rules-and-regulations', pathMatch: 'full' },
      {
        path: 'rules-and-regulations',
        component: RulesAndRegulationsComponent,
        data: {
          title: 'Rules and Regulations',
          urls: [
            { title: 'Rules and Regulations', url: '/home/rules-and-regulations' },
            { title: 'Rules and Regulations' }
          ]
        }
      },
      ...registrationRoutes,
      {
        path: 'registration',
        component: RegistrationComponent,
        data: {
          title: 'Registrations',
          urls: [
            { title: 'home', url: '/home/rules-and-regulations' },
            { title: 'registrations' }
          ]
        }
      },
      {
        path: 'plan',
        component: PlanComponent,
        data: {
          title: 'Academic Plan',
          urls: [
            { title: 'home', url: '/home/rules-and-regulations' },
            { title: 'plan' }
          ]
        }
      },
      {
        path: 'result',
        component: ResultComponent,
        data: {
          title: 'Academic Results',
          urls: [
            { title: 'home', url: '/home/rules-and-regulations' },
            { title: 'results' }
          ]
        }
      },
      {
        path: 'timetable',
        component: TimetableComponent,
        data: {
          title: 'Academic Timetable',
          urls: [
            { title: 'home', url: '/home/rules-and-regulations' },
            { title: 'timetable' }
          ]
        }
      },
      {
        path: 'accounts',
        component: AccountsComponent,
        data: {
          title: 'Accounts',
          urls: [
            { title: 'home', url: '/home/rules-and-regulations' },
            { title: 'accounts' }
          ]
        }
      },
      {
        path: 'lecturer-evaluation',
        component: LecturerEvaluationComponent,
        data: {
          title: 'Lecturer Evaluation',
          urls: [
            { title: 'home', url: '/home/rules-and-regulations' },
            { title: 'lecturer evaluation' }
          ]
        }
      },
      {
        path: 'document-requests',
        component: DocumentRequestsComponent,
        data: {
          title: 'Document-requests',
          urls: [
            { title: 'home', url: '/home/rules-and-regulations' },
            { title: 'document requests' }
          ]
        }
      },
      {
        path: 'profile',
        component: ProfileComponent,
        data: {
          title: 'My Profile',
          urls: [
            {title: 'home', url: '/home/rules-and-regulations'},
            {title: 'profile'}
          ]
        }
      },
      {
        path: 'account-settings',
        component: AccountSettingsComponent,
        data: {
          title: 'Account Settings',
          urls: [
            {title: 'home', url: '/home/rules-and-regulations'},
            {title: 'account settings'}
          ]
        }
      },
      {
        path: 'starter',
        loadChildren: './views/starter/starter.module#StarterModule'
      },
      {
        path: '**',
        component: NotfoundComponent
      }
    ]
  },
  {
    path: '**',
    component: NotfoundComponent
  }
];
