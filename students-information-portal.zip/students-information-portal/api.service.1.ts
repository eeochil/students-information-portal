import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable, OperatorFunction, throwError } from 'rxjs';
import { environment } from '../../environments/environment';
import { AuthDataService } from './auth-data.service';
import { map, retry, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  EVN = environment;
  baseUrl: string | '';
  endpoint: string | '';
  httpOptions: any;
  // tslint:disable-next-line:max-line-length
  defaultHeaderParams = {'Content-Type': 'application/json' , 'client_id': this.EVN.API_CLIENT_ID, 'client_secret': this.EVN.API_CLIENT_SECRET};

  constructor(private http: HttpClient, private apiData: AuthDataService) {
    this.httpOptions = {
      headers: new HttpHeaders({
         })
    };
  }

  // private functions
  // ==================
  /**
   * Handles Http Request Errors
   * @param error error object of HttpResponseError.
   */

  private httpErrorResponses(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      // when error is at the client side.
      console.log(`client side error ${error.error}`);
    } else {
      // when error is at the server side.
      console.error(`server error ${error.error}`);
    }

    return throwError('Something went wrong');
  }

  /**
   * set HttpRequest parameter and headers
   * @param params header parameters.
   * @param url endpoint for the request.
  */
  private setRequestParameters(url, params = null): object {
    this.baseUrl = this.EVN.API_BASE_URL + url;
    if (params) {
      const hd = Object.assign(this.defaultHeaderParams, params);
      return this.httpOptions = {
        headers: new HttpHeaders(hd)
      };
    } else {
      return this.httpOptions = {
        headers: new HttpHeaders(this.defaultHeaderParams)
      };
    }
  }

  /**
   * remove if the object exist.
   * @param obj the object to seach.
   * 
  */

  removeEmpty(obj) {
    if ( obj ) {
      const o = JSON.parse(JSON.stringify(obj)); // Clone source oect.
      Object.keys(o).forEach(key => {
        if (o[key] && typeof o[key] === 'object') {
          o[key] = this.removeEmpty(o[key]);
        } else if (o[key] === undefined || o[key] === null || o[key] === '') {
          delete o[key];
        } else {
          o[key] = o[key];
        }  // Copy value.
      });

      return o; // Return new object.
    }

    return null;
  }
  // end of private functions


  /**
   * Runs Http GET request for subscription.
   * @param url this is the endpoint for the api.
   * @param params this holds the query parameters.
  */

  public get(url,  params: object = null, param_headers: object = null): Observable<any> {
    const requestHeader = this.setRequestParameters(url, param_headers );
    this.httpOptions['queryParams'] = this.removeEmpty(params);
    return this.http.get(this.baseUrl, requestHeader).pipe(retry(1), catchError( this.httpErrorResponses));
  }

  /**
   * Runs Http POST request for subscription.
   * @param url endpoint for the post api.
   * @param params post parameters.
   * @param qparams post query parameters.
   * @param param_headers additional request header.
   *
  */
  public post(url,  params: object = null, qparams, param_headers: object = null): Observable<any> {
    const requestHeader = this.setRequestParameters(url, param_headers );
    
    if (qparams) {
      this.httpOptions['queryParams'] = this.removeEmpty(qparams);
    }
    return this.http.post(this.baseUrl, params, requestHeader).pipe(retry(1), catchError( this.httpErrorResponses));
  }
